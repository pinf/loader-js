
module.declare([], function(require, exports, module)
{
    exports.main = function()
    {
        module.print("Hello World from Zipped!\n");
    }
});
